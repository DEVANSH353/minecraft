<script lang="ts">
    const idBase = `lb-logo-${Math.random().toString(36).slice(2, 9)}`;
    const bannerGradientId = `${idBase}-banner`;
    const bannerTextGradientId = `${idBase}-banner-text`;

    const anniversary = (new Date()).getFullYear() - 2016;
</script>

<div class="animated-logo">
    <svg
            class="logo-svg"
            xmlns="http://www.w3.org/2000/svg"
            width="261.263"
            height="98"
            viewBox="0 0 261.263 98"
            role="img"
            aria-label="LiquidBounce logo"
    >
        <defs>
            <linearGradient id={bannerGradientId} gradientUnits="userSpaceOnUse" spreadMethod="repeat"
                            x1="48" y1="16" x2="372" y2="164">
                <stop offset="0%" stop-color="#4677ff"/>
                <stop offset="50%" stop-color="#fc4130"/>
                <stop offset="100%" stop-color="#4677ff"/>
                <animateTransform
                        attributeName="gradientTransform"
                        type="translate"
                        dur="9.1s"
                        repeatCount="indefinite"
                        calcMode="linear"
                        values="0 0; 324 148"
                />
            </linearGradient>

            <linearGradient id={bannerTextGradientId} gradientUnits="userSpaceOnUse" spreadMethod="repeat"
                            x1="72" y1="34" x2="324" y2="149">
                <stop offset="0%" stop-color="#dbe6ff"/>
                <stop offset="50%" stop-color="#ffd4cf"/>
                <stop offset="100%" stop-color="#dbe6ff"/>
                <animateTransform
                        attributeName="gradientTransform"
                        type="translate"
                        dur="7s"
                        repeatCount="indefinite"
                        calcMode="linear"
                        values="0 0; 252 115"
                />
            </linearGradient>
        </defs>

        <g fill="#fff">
            <path d="M79.9,39.948A39.967,39.967,0,0,0,39.947,0H0V39.948a39.948,39.948,0,1,0,79.9,0Z"
                  fill-rule="evenodd"/>
            <path d="M62.357,42.2H76.984v7.232H54.8V11.078h7.56Z" transform="translate(37.791 7.64)"/>
            <path d="M70.47,11.078h7.56v38.35H70.47Z" transform="translate(48.6 7.64)"/>
            <path d="M117.938,30.566A19.2,19.2,0,0,1,113.226,43.5l3.945,4.109L111.8,52.371l-4.164-4.328A19.529,19.529,0,0,1,98,50.508,19.737,19.737,0,0,1,78.108,30.566a19.121,19.121,0,0,1,5.807-14.134,19.972,19.972,0,0,1,28.16,0A19.033,19.033,0,0,1,117.938,30.566ZM98,43.112a13.443,13.443,0,0,0,4.273-.712l-6.3-6.574,5.369-4.766,6.739,7.012a12.768,12.768,0,0,0,2.3-7.506,12.247,12.247,0,0,0-3.561-9.039,12.7,12.7,0,0,0-17.641,0,12.248,12.248,0,0,0-3.561,9.039,12.18,12.18,0,0,0,3.561,8.985A11.979,11.979,0,0,0,98,43.112Z"
                  transform="translate(53.868 7.327)"/>
            <path d="M119.258,50.195a15.335,15.335,0,0,1-10.518-3.616,12.271,12.271,0,0,1-4.109-9.7v-25.8h7.505v25.2a6.56,6.56,0,0,0,1.7,4.766q1.754,1.753,5.424,1.753t5.37-1.753a6.445,6.445,0,0,0,1.752-4.766v-25.2h7.561v25.8a12.271,12.271,0,0,1-4.109,9.7A15.416,15.416,0,0,1,119.258,50.195Z"
                  transform="translate(72.159 7.64)"/>
            <path d="M126.009,11.078h7.56v38.35h-7.56Z" transform="translate(86.903 7.64)"/>
            <path d="M149.916,11.078a17.388,17.388,0,0,1,13.147,5.533,18.935,18.935,0,0,1,5.314,13.641,18.935,18.935,0,0,1-5.314,13.642,17.388,17.388,0,0,1-13.147,5.533H134.685V11.078Zm0,31.118a10.675,10.675,0,0,0,8.107-3.287,12.17,12.17,0,0,0,3.122-8.656,11.974,11.974,0,0,0-3.122-8.6,10.587,10.587,0,0,0-8.107-3.342h-7.671V42.2Z"
                  transform="translate(92.886 7.64)"/>
        </g>

        <g class="bounce-part">
            <path d="M90.05,45.9a7.618,7.618,0,0,1,7.428-6.726h96.054a6,6,0,0,1,6.09,6.726L197.8,64.255a7.619,7.619,0,0,1-7.428,6.726H94.314a6,6,0,0,1-6.09-6.726Z"
                  transform="translate(60.821 27.02)" fill={`url(#${bannerGradientId})`}/>

            <g fill={`url(#${bannerTextGradientId})`}>
                <path d="M107.571,51.278a3.158,3.158,0,0,1,1.68,2.922,3.434,3.434,0,0,1-1.151,2.666,4.06,4.06,0,0,1-2.83,1.041H99.846V45.123h5.04a3.922,3.922,0,0,1,2.758,1.023,3.285,3.285,0,0,1,1.132,2.575A3.115,3.115,0,0,1,107.571,51.278Zm-2.685-3.8h-2.519v2.812h2.519a1.279,1.279,0,0,0,.968-.4,1.36,1.36,0,0,0,.4-1,1.4,1.4,0,0,0-.384-1A1.3,1.3,0,0,0,104.886,47.479Zm.384,8.072a1.437,1.437,0,0,0,1.059-.42,1.52,1.52,0,0,0,.421-1.1,1.435,1.435,0,0,0-.421-1.059,1.407,1.407,0,0,0-1.059-.438h-2.9v3.013Z"
                      transform="translate(68.86 31.12)"/>
                <path d="M117.385,56.349a6.656,6.656,0,1,1,0-9.441,6.722,6.722,0,0,1,0,9.441Zm-7.652-1.717a4.284,4.284,0,0,0,5.882,0,4.42,4.42,0,0,0,0-6.026,4.237,4.237,0,0,0-5.882,0,4.42,4.42,0,0,0,0,6.026Z"
                      transform="translate(73.134 31.015)"/>
                <path d="M119.708,58.162a5.11,5.11,0,0,1-3.506-1.205,4.092,4.092,0,0,1-1.37-3.232v-8.6h2.5v8.4a2.189,2.189,0,0,0,.566,1.589,2.464,2.464,0,0,0,1.808.584,2.4,2.4,0,0,0,1.789-.584,2.144,2.144,0,0,0,.585-1.589v-8.4H124.6v8.6a4.092,4.092,0,0,1-1.37,3.232A5.138,5.138,0,0,1,119.708,58.162Z"
                      transform="translate(79.194 31.12)"/>
                <path d="M129.355,45.123h2.519V57.906h-1.918l-5.478-7.816v7.816h-2.521V45.123h1.918l5.48,7.8Z"
                      transform="translate(84.109 31.12)"/>
                <path d="M135.532,58.267a6.393,6.393,0,0,1-4.767-1.918,6.888,6.888,0,0,1,0-9.46,6.782,6.782,0,0,1,7.962-1.1,5.862,5.862,0,0,1,2.3,2.191l-2.173,1.26a3.322,3.322,0,0,0-1.352-1.333,3.954,3.954,0,0,0-1.972-.493,4.043,4.043,0,0,0-3.014,1.169,4.6,4.6,0,0,0,0,6.045,4.418,4.418,0,0,0,4.986.694,3.317,3.317,0,0,0,1.352-1.333l2.173,1.26a6.036,6.036,0,0,1-2.283,2.21A6.564,6.564,0,0,1,135.532,58.267Z"
                      transform="translate(88.886 31.015)"/>
                <path d="M139.509,55.5H144.9v2.41h-7.908V45.123H144.8v2.41h-5.3v2.721h4.839v2.374h-4.839Z"
                      transform="translate(94.474 31.12)"/>
            </g>
        </g>
    </svg>

    <div class="divider"></div>

    <div class="message">
        <div>Thank you for <span>{anniversary} Years</span></div>
        <div>of LiquidBounce!</div>
    </div>
</div>

<style>
    .animated-logo {
        display: flex;
        column-gap: 30px;
    }

    .logo-svg {
        display: block;
        width: 261.263px;
        height: 98px;
        flex: 0 0 auto;
        overflow: visible;
    }

    .divider {
        background-color: white;
        width: 2px;
        flex: 1;
    }

    .message {
        color: white;
        font-size: 25px;
        font-weight: 500;
        line-height: 40px;
        justify-content: center;
        display: flex;
        flex-direction: column;

        span {
            color: #EFBF04;
            font-weight: 600;
        }
    }

    .bounce-part {
        filter: drop-shadow(0 0 16px rgba(70, 119, 255, 0.22)) drop-shadow(0 0 30px rgba(252, 65, 48, 0.12));
    }
</style>
